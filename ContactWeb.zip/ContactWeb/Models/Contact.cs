﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
     public class Contact
    {
        [Key]
        public int ContactId { get; set; }
        [Required]
        public int FirstName { get; set; }
        public int LastName { get; set; }
        [Required]
        public int Phone { get; set; }
        public int Email { get; set; }
        public int Address{ get; set; }
    }
}
