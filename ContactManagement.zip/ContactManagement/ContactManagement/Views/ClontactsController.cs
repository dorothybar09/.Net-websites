﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ContactManagement;
using Models;

namespace ContactManagement.Views
{
    public class ClontactsController : Controller
    {
        private readonly AppDbContext _context;

        public ClontactsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Clontacts
        public async Task<IActionResult> Index()
        {
              return View(await _context.Clontact.ToListAsync());
        }

        // GET: Clontacts/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Clontact == null)
            {
                return NotFound();
            }

            var clontact = await _context.Clontact
                .FirstOrDefaultAsync(m => m.ContactId == id);
            if (clontact == null)
            {
                return NotFound();
            }

            return View(clontact);
        }

        // GET: Clontacts/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Clontacts/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ContactId,FirstName,LastName,Phone,Email,Address")] Clontact clontact)
        {
            if (ModelState.IsValid)
            {
                _context.Add(clontact);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(clontact);
        }

        // GET: Clontacts/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Clontact == null)
            {
                return NotFound();
            }

            var clontact = await _context.Clontact.FindAsync(id);
            if (clontact == null)
            {
                return NotFound();
            }
            return View(clontact);
        }

        // POST: Clontacts/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ContactId,FirstName,LastName,Phone,Email,Address")] Clontact clontact)
        {
            if (id != clontact.ContactId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(clontact);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ClontactExists(clontact.ContactId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(clontact);
        }

        // GET: Clontacts/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Clontact == null)
            {
                return NotFound();
            }

            var clontact = await _context.Clontact
                .FirstOrDefaultAsync(m => m.ContactId == id);
            if (clontact == null)
            {
                return NotFound();
            }

            return View(clontact);
        }

        // POST: Clontacts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Clontact == null)
            {
                return Problem("Entity set 'AppDbContext.Clontact'  is null.");
            }
            var clontact = await _context.Clontact.FindAsync(id);
            if (clontact != null)
            {
                _context.Clontact.Remove(clontact);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ClontactExists(int id)
        {
          return _context.Clontact.Any(e => e.ContactId == id);
        }
    }
}
