﻿using Microsoft.EntityFrameworkCore;
using Models;
namespace ContactManagement
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<Clontact> Clontact { get; set; }
    }
}
